<?php
/****************************************************/
/************** Created by : Vivek Gupta ************/
/***************     www.vsgupta.in     *************/
/***************     www.iotmonk.com     *************/
/****************************************************/ 

define('DB_USER', "id2928513_aadityamonu67");     // Your database user name
define('DB_PASSWORD', "Indiacan420");			// Your database password (mention your db password here)
define('DB_DATABASE', "id2928513_dbcrud"); // Your database name
define('DB_SERVER', "localhost");			// db server (Mostly will be 'local' host)

?>